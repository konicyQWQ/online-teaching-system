import{a as r,o as e,c as a}from"./index.3497d165.js";var t={};t.render=function(t,n,o,s,d,i){const u=r("router-view");return e(),a(u,{name:"extra"})};export default t;
