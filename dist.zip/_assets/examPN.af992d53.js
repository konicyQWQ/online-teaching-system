import{a as r,o as e,c as o}from"./index.3497d165.js";var t={};t.render=function(t,a,n,s,d,i){const u=r("router-view");return e(),o(u)};export default t;
